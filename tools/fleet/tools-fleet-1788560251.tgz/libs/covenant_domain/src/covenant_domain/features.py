from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Literal, TypedDict

from .models import CovenantResult, Deal

# =============================================================================
# Risk Tier Type and Classification
# =============================================================================

RiskTier = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
"""Risk tier classification for ML predictions.

Thresholds:
- LOW: probability < 0.25
- MEDIUM: 0.25 <= probability < 0.50
- HIGH: 0.50 <= probability < 0.80
- CRITICAL: probability >= 0.80
"""

RISK_TIERS: tuple[RiskTier, ...] = ("LOW", "MEDIUM", "HIGH", "CRITICAL")
"""The accepted tiers, declared so something can check the copies.

This set was spelled SEVEN ways: ``RiskTier`` here and again in
``platform_core.covenant_metrics_events``, ``RiskTierValue`` in
covenant-radar-api, four inline ``Literal[...]`` on fields and parameters,
and a ``VALID_RISK_TIERS`` tuple beside one of them. Widening any one of them
type-checks, because they are independent annotations and mypy has no reason
to relate them -- so a decoder would come to accept a tier the classifier
never produces, and the failure would surface as a prediction filed under a
tier nothing reads.

``monorepo_guards.literal_set_rules.RISK_TIER_SET`` reads this tuple and
requires every ``risk_tier`` annotation in the monorepo to name exactly it.
"""


def classify_risk_tier(probability: float) -> RiskTier:
    """Classify probability into risk tier.

    Uses standard thresholds:
    - LOW: probability < 0.25
    - MEDIUM: 0.25 <= probability < 0.50
    - HIGH: 0.50 <= probability < 0.80
    - CRITICAL: probability >= 0.80

    Args:
        probability: Risk probability between 0.0 and 1.0.

    Returns:
        Categorized RiskTier.
    """
    if probability < 0.25:
        return "LOW"
    if probability < 0.50:
        return "MEDIUM"
    if probability < 0.80:
        return "HIGH"
    return "CRITICAL"


# =============================================================================
# Feature Types
# =============================================================================


class LoanFeatures(TypedDict, total=True):
    """Feature vector for ML risk prediction. All values are floats."""

    debt_to_ebitda: float
    interest_cover: float
    current_ratio: float
    leverage_change_1p: float  # vs 1 period ago
    leverage_change_4p: float  # vs 4 periods ago
    sector_encoded: int
    region_encoded: int
    near_breach_count_4p: int  # near breaches in last 4 periods


class RiskPrediction(TypedDict, total=True):
    """ML model prediction output."""

    probability: float
    risk_tier: RiskTier


# Feature column order for numpy array conversion
FEATURE_ORDER: tuple[str, ...] = (
    "debt_to_ebitda",
    "interest_cover",
    "current_ratio",
    "leverage_change_1p",
    "leverage_change_4p",
    "sector_encoded",
    "region_encoded",
    "near_breach_count_4p",
)


def _count_near_breaches(results: Sequence[CovenantResult], periods: int) -> int:
    """Count NEAR_BREACH status in last N periods."""
    count = 0
    # Assume results are sorted by period descending
    for result in results[:periods]:
        if result["status"] == "NEAR_BREACH":
            count += 1
    return count


def _safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Safe division that returns default on zero denominator."""
    if denominator == 0.0:
        return default
    return numerator / denominator


# The metric names extract_features reads out of metrics_current. Published so
# callers can check completeness before calling, rather than discovering a
# missing metric as a KeyError from inside feature extraction.
REQUIRED_CURRENT_METRICS: tuple[str, ...] = (
    "total_debt",
    "ebitda",
    "interest_expense",
    "current_assets",
    "current_liabilities",
)


def extract_features(
    deal: Deal,
    metrics_current: Mapping[str, int],
    metrics_1p_ago: Mapping[str, int],
    metrics_4p_ago: Mapping[str, int],
    recent_results: Sequence[CovenantResult],
    sector_encoder: Mapping[str, int],
    region_encoder: Mapping[str, int],
) -> LoanFeatures:
    """
    Extract ML features from domain data. Pure function.

    metrics_*: metric_name -> scaled_value (multiply by 1_000_000)
    recent_results: Last N covenant results, sorted by period descending

    Raises KeyError if required metrics missing or sector/region unknown.
    """
    # Current period ratios (convert from scaled int to float)
    debt = metrics_current["total_debt"] / 1_000_000
    ebitda = metrics_current["ebitda"] / 1_000_000
    interest = metrics_current["interest_expense"] / 1_000_000
    current_assets = metrics_current["current_assets"] / 1_000_000
    current_liab = metrics_current["current_liabilities"] / 1_000_000

    debt_to_ebitda = _safe_divide(debt, ebitda)
    interest_cover = _safe_divide(ebitda, interest)
    current_ratio = _safe_divide(current_assets, current_liab)

    # Historical leverage for change calculation
    debt_1p = metrics_1p_ago.get("total_debt", 0) / 1_000_000
    ebitda_1p = metrics_1p_ago.get("ebitda", 1_000_000) / 1_000_000
    leverage_1p = _safe_divide(debt_1p, ebitda_1p)

    debt_4p = metrics_4p_ago.get("total_debt", 0) / 1_000_000
    ebitda_4p = metrics_4p_ago.get("ebitda", 1_000_000) / 1_000_000
    leverage_4p = _safe_divide(debt_4p, ebitda_4p)

    leverage_change_1p = debt_to_ebitda - leverage_1p
    leverage_change_4p = debt_to_ebitda - leverage_4p

    # Categorical encoding (raises KeyError if unknown)
    sector_encoded = sector_encoder[deal["sector"]]
    region_encoded = region_encoder[deal["region"]]

    # Near breach count
    near_breach_count = _count_near_breaches(recent_results, 4)

    return LoanFeatures(
        debt_to_ebitda=debt_to_ebitda,
        interest_cover=interest_cover,
        current_ratio=current_ratio,
        leverage_change_1p=leverage_change_1p,
        leverage_change_4p=leverage_change_4p,
        sector_encoded=sector_encoded,
        region_encoded=region_encoded,
        near_breach_count_4p=near_breach_count,
    )


__all__ = [
    "FEATURE_ORDER",
    "REQUIRED_CURRENT_METRICS",
    "LoanFeatures",
    "RiskPrediction",
    "RiskTier",
    "classify_risk_tier",
    "extract_features",
]
