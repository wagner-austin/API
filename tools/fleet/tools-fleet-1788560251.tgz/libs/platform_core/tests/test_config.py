from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from platform_core.config import (
    _decode_table,
    _decode_toml,
    _optional_env_str,
    _parse_bool,
    _parse_float,
    _parse_int,
    _parse_log_format,
    _parse_log_level,
    _parse_str,
    _require_env_csv,
    _require_env_str,
)
from platform_core.config._utils import _validate_log_format, _validate_log_level
from platform_core.config.art_trainer import load_settings as load_art_trainer_settings
from platform_core.config.data_bank import load_settings as load_data_bank_settings
from platform_core.config.turkic_api import load_settings as load_turkic_api_settings
from platform_core.json_utils import JSONTypeError, JSONValue
from platform_core.testing import make_fake_env


def test_require_env_str_missing() -> None:
    make_fake_env()
    with pytest.raises(RuntimeError):
        _require_env_str("MISSING_KEY")


def test_require_env_str_blank() -> None:
    env = make_fake_env()
    env.set("BLANK_KEY", "   ")
    with pytest.raises(RuntimeError):
        _require_env_str("BLANK_KEY")


def test_optional_env_str() -> None:
    env = make_fake_env()
    assert _optional_env_str("OPT_KEY") is None
    env.set("OPT_KEY", " value ")
    assert _optional_env_str("OPT_KEY") == "value"
    env.set("OPT_KEY", "   ")
    assert _optional_env_str("OPT_KEY") is None


def test_require_env_csv() -> None:
    env = make_fake_env()
    env.set("CSV_KEY", " alpha , beta,,gamma ")
    out = _require_env_csv("CSV_KEY")
    assert out == frozenset({"alpha", "beta", "gamma"})
    env.set("CSV_KEY", "   ")
    with pytest.raises(RuntimeError):
        _require_env_csv("CSV_KEY")
    env.set("CSV_KEY", " , , ")
    with pytest.raises(RuntimeError):
        _require_env_csv("CSV_KEY")


def test_load_toml_success(tmp_path: Path) -> None:
    path = tmp_path / "config.toml"
    path.write_text('[section]\nkey = "value"\n', encoding="utf-8")
    out = _decode_toml(path)
    assert out == {"section": {"key": "value"}}


def test_load_toml_invalid_syntax_propagates(tmp_path: Path) -> None:
    path = tmp_path / "config.toml"
    path.write_text("123\n", encoding="utf-8")
    with pytest.raises(tomllib.TOMLDecodeError):
        _decode_toml(path)


def test_load_toml_uses_hook(tmp_path: Path) -> None:
    """Test that _decode_toml uses the tomllib_loads hook."""
    from platform_core.config import _test_hooks

    path = tmp_path / "config.toml"
    path.write_text("value = 1\n", encoding="utf-8")

    def _fake_tomllib_loads(_: str) -> dict[str, JSONValue]:
        return {"hooked": True}

    _test_hooks.tomllib_loads = _fake_tomllib_loads
    result = _decode_toml(path)
    assert result == {"hooked": True}


def test_decode_table_success() -> None:
    result = _decode_table({"section": {"key": "value"}}, "section")
    assert result == {"key": "value"}


def test_decode_table_wrong_type() -> None:
    with pytest.raises(RuntimeError):
        _decode_table({"section": "not-a-table"}, "section")


def test_decode_table_missing() -> None:
    assert _decode_table({}, "missing") == {}


def test_load_data_bank_settings() -> None:
    env = make_fake_env()
    env.set("REDIS_URL", "redis://ignored")
    env.set("API_UPLOAD_KEYS", "one,two")
    cfg = load_data_bank_settings()
    assert cfg["api_upload_keys"] == frozenset({"one", "two"})
    assert cfg["api_read_keys"] == cfg["api_upload_keys"]
    assert cfg["api_delete_keys"] == cfg["api_upload_keys"]
    assert cfg["data_root"] == "/data/files"
    assert cfg["min_free_gb"] == 1
    assert cfg["delete_strict_404"] is False
    assert cfg["max_file_bytes"] == 0


def test_load_data_bank_settings_reads_the_environment() -> None:
    """The four storage knobs come from the environment, not from literals.

    They WERE literals, which meant data-bank-api's own ``railway.toml`` had
    been setting ``DATA_ROOT``, ``MIN_FREE_GB`` and ``DELETE_STRICT_404``
    into a loader that ignored all three -- the deployment declared a 2 GB
    free-space floor and ran on 1. The defaults above are unchanged, so this
    is the test that says the values are now reachable at all.
    """
    env = make_fake_env()
    env.set("REDIS_URL", "redis://ignored")
    env.set("API_UPLOAD_KEYS", "one")
    env.set("DATA_ROOT", "/srv/bank")
    env.set("MIN_FREE_GB", "2")
    env.set("DELETE_STRICT_404", "true")
    env.set("MAX_FILE_BYTES", "1048576")
    cfg = load_data_bank_settings()
    assert cfg["data_root"] == "/srv/bank"
    assert cfg["min_free_gb"] == 2
    assert cfg["delete_strict_404"] is True
    assert cfg["max_file_bytes"] == 1048576


def test_load_turkic_api_settings_defaults() -> None:
    env = make_fake_env()
    env.set("TURKIC_DATA_BANK_API_KEY", "secret")
    cfg = load_turkic_api_settings()
    assert cfg["data_bank_api_key"] == "secret"
    assert cfg["redis_url"] == "redis://redis:6379/0"
    assert cfg["data_dir"] == "/data"
    assert cfg["environment"] == "local"
    assert cfg["data_bank_api_url"] == ""


def test_load_turkic_api_settings_override() -> None:
    env = make_fake_env()
    env.set("TURKIC_DATA_BANK_API_KEY", "secret")
    env.set("TURKIC_REDIS_URL", "redis://override")
    cfg = load_turkic_api_settings()
    assert cfg["redis_url"] == "redis://override"


def test_parse_str() -> None:
    env = make_fake_env()
    assert _parse_str("STR_KEY", "default") == "default"
    env.set("STR_KEY", " value ")
    assert _parse_str("STR_KEY", "default") == "value"
    env.set("STR_KEY", "   ")
    assert _parse_str("STR_KEY", "default") == "default"


def test_parse_int() -> None:
    env = make_fake_env()
    assert _parse_int("INT_KEY", 42) == 42
    env.set("INT_KEY", " 123 ")
    assert _parse_int("INT_KEY", 42) == 123
    env.set("INT_KEY", "not-a-number")
    with pytest.raises(ValueError):
        _parse_int("INT_KEY", 42)


def test_parse_float() -> None:
    env = make_fake_env()
    assert _parse_float("FLOAT_KEY", 3.14) == 3.14
    env.set("FLOAT_KEY", " 2.5 ")
    assert _parse_float("FLOAT_KEY", 3.14) == 2.5
    env.set("FLOAT_KEY", "not-a-float")
    with pytest.raises(ValueError):
        _parse_float("FLOAT_KEY", 3.14)


def test_parse_bool() -> None:
    env = make_fake_env()
    assert _parse_bool("BOOL_KEY", False) is False
    assert _parse_bool("BOOL_KEY", True) is True

    for true_val in ["1", "true", "TRUE", "yes", "YES", "y", "Y", "on", "ON"]:
        env.set("BOOL_KEY", true_val)
        assert _parse_bool("BOOL_KEY", False) is True

    for false_val in ["0", "false", "FALSE", "no", "NO", "n", "N", "off", "OFF"]:
        env.set("BOOL_KEY", false_val)
        assert _parse_bool("BOOL_KEY", True) is False

    env.set("BOOL_KEY", "invalid")
    with pytest.raises(ValueError):
        _parse_bool("BOOL_KEY", False)


def test_parse_log_level() -> None:
    env = make_fake_env()
    assert _parse_log_level("LOG_LEVEL", "INFO") == "INFO"

    for level in ["DEBUG", "debug", "Debug"]:
        env.set("LOG_LEVEL", level)
        assert _parse_log_level("LOG_LEVEL", "INFO") == "DEBUG"

    env.clear()
    for level in ["INFO", "info", "Info"]:
        env.set("LOG_LEVEL", level)
        assert _parse_log_level("LOG_LEVEL", "DEBUG") == "INFO"

    env.clear()
    for level in ["WARNING", "warning", "Warning"]:
        env.set("LOG_LEVEL", level)
        assert _parse_log_level("LOG_LEVEL", "INFO") == "WARNING"

    env.clear()
    for level in ["ERROR", "error", "Error"]:
        env.set("LOG_LEVEL", level)
        assert _parse_log_level("LOG_LEVEL", "INFO") == "ERROR"

    env.clear()
    for level in ["CRITICAL", "critical", "Critical"]:
        env.set("LOG_LEVEL", level)
        assert _parse_log_level("LOG_LEVEL", "INFO") == "CRITICAL"

    env.clear()
    env.set("LOG_LEVEL", "invalid")
    with pytest.raises(JSONTypeError, match="Invalid log level: invalid"):
        _parse_log_level("LOG_LEVEL", "WARNING")


def test_parse_log_format() -> None:
    env = make_fake_env()
    assert _parse_log_format("LOG_FORMAT", "json") == "json"

    for spelling in ["TEXT", "text", "Text"]:
        env.set("LOG_FORMAT", spelling)
        assert _parse_log_format("LOG_FORMAT", "json") == "text"

    env.clear()
    env.set("LOG_FORMAT", "json")
    assert _parse_log_format("LOG_FORMAT", "text") == "json"

    env.clear()
    env.set("LOG_FORMAT", "yaml")
    with pytest.raises(JSONTypeError, match="Invalid log format: yaml"):
        _parse_log_format("LOG_FORMAT", "json")


class TestValidatingALogLevel:
    """An unrecognised level is refused rather than quietly downgraded.

    `_parse_log_level` used to return the default, so `LOG_LEVEL=TRACE`
    started the service at INFO and logged nothing about it -- and the levels
    an operator is most likely to mistype are the verbose ones they reached
    for while debugging, so the failure hid exactly the output that was asked
    for. `grandma-api` and `opportunity-radar-api` had each written a strict
    copy beside it rather than fix it; those copies are gone and this is the
    one that remains.
    """

    def test_every_level_is_accepted_in_any_case(self) -> None:
        assert _validate_log_level("debug") == "DEBUG"
        assert _validate_log_level("INFO") == "INFO"
        assert _validate_log_level("Warning") == "WARNING"
        assert _validate_log_level("ERROR") == "ERROR"
        assert _validate_log_level("critical") == "CRITICAL"

    def test_an_unrecognised_level_is_refused(self) -> None:
        with pytest.raises(JSONTypeError, match="Invalid log level: TRACE"):
            _validate_log_level("TRACE")


class TestValidatingALogFormat:
    """The set is `json` and `text`, and it is now spelled once.

    It had been written three times -- `platform_core.logging` plus a copy in
    each of the two services -- which is the shape a fourth copy spelling
    `console` would have joined without anything noticing.
    """

    def test_both_formats_are_accepted_in_any_case(self) -> None:
        assert _validate_log_format("JSON") == "json"
        assert _validate_log_format("Text") == "text"

    def test_an_unrecognised_format_is_refused(self) -> None:
        with pytest.raises(JSONTypeError, match="Invalid log format: console"):
            _validate_log_format("console")


def test_default_get_env_returns_real_environ() -> None:
    """Test _default_get_env reads from real os.environ."""
    import os

    from platform_core.config._test_hooks import _default_get_env

    # Test getting a key that exists in real environment
    result = _default_get_env("PATH")
    assert result == os.getenv("PATH")

    # Test getting a key that doesn't exist
    result = _default_get_env("__DEFINITELY_NOT_A_REAL_ENV_VAR__")
    assert result is None


def test_default_get_environment_returns_the_whole_real_environ() -> None:
    """Test _default_get_environment answers the process question, not the
    configuration one: what a CHILD should inherit.

    ``subprocess`` replaces the environment wholesale when given one, so a
    caller adding a single variable has to start from the parent's -- and this
    module is the only one permitted to read it.
    """
    import os

    from platform_core.config._test_hooks import _default_get_environment

    assert _default_get_environment() == dict(os.environ)


def test_default_get_environment_returns_a_copy() -> None:
    """A caller's overlay must not reach back into this process's own
    environment: it is building a child's, not editing its own."""
    from platform_core.config._test_hooks import _default_get_environment

    first = _default_get_environment()
    first["__PLATFORM_CORE_TEST_ONLY__"] = "1"
    assert "__PLATFORM_CORE_TEST_ONLY__" not in _default_get_environment()


def test_fake_env_delete() -> None:
    """Test FakeEnv.delete removes a key."""
    env = make_fake_env({"KEY": "value"})
    assert env.get("KEY") == "value"
    env.delete("KEY")
    assert env.get("KEY") is None
    # Deleting non-existent key should not raise
    env.delete("NONEXISTENT")


def test_load_art_trainer_settings_defaults() -> None:
    """Test load_art_trainer_settings with default values."""
    make_fake_env()
    cfg = load_art_trainer_settings()
    assert cfg["app_env"] == "dev"
    assert cfg["logging"]["level"] == "INFO"
    assert cfg["redis"]["enabled"] is True
    assert cfg["redis"]["url"] == "redis://redis:6379/0"
    assert cfg["rq"]["queue_name"] == "art-trainer"
    assert cfg["rq"]["job_timeout_sec"] == 86_400
    assert cfg["rq"]["result_ttl_sec"] == 86_400
    assert cfg["rq"]["failure_ttl_sec"] == 7 * 86_400
    assert cfg["rq"]["retry_max"] == 1
    assert cfg["rq"]["retry_intervals_sec"] == "300"
    assert cfg["app"]["data_root"] == "/data"
    assert cfg["app"]["output_root"] == "/data/output"
    assert cfg["app"]["logs_root"] == "/data/logs"
    assert cfg["app"]["data_bank_api_url"] == ""
    assert cfg["app"]["data_bank_api_key"] == ""
    assert cfg["app"]["kohya_ss_path"] == "/opt/kohya_ss"
    assert cfg["app"]["comfyui_lora_path"] == "/opt/ComfyUI/models/loras"
    assert cfg["app"]["blip_model_name"] == "Salesforce/blip-image-captioning-large"
    assert cfg["app"]["caption_trigger_word"] == "sks person"
    assert cfg["security"]["api_key"] == ""


def test_load_art_trainer_settings_prod_env() -> None:
    """Test load_art_trainer_settings with prod environment."""
    env = make_fake_env()
    env.set("APP_ENV", "prod")
    cfg = load_art_trainer_settings()
    assert cfg["app_env"] == "prod"


def test_load_art_trainer_settings_gateway_url() -> None:
    """Test load_art_trainer_settings prefers API_GATEWAY_URL over direct URL."""
    env = make_fake_env()
    env.set("API_GATEWAY_URL", "https://gateway.example.com")
    env.set("APP__DATA_BANK_API_URL", "https://direct.example.com")
    cfg = load_art_trainer_settings()
    assert cfg["app"]["data_bank_api_url"] == "https://gateway.example.com/data-bank"


def test_load_art_trainer_settings_direct_url() -> None:
    """Test load_art_trainer_settings uses direct URL when gateway not set."""
    env = make_fake_env()
    env.set("APP__DATA_BANK_API_URL", "https://direct.example.com")
    cfg = load_art_trainer_settings()
    assert cfg["app"]["data_bank_api_url"] == "https://direct.example.com"


def test_load_art_trainer_settings_log_level_debug() -> None:
    """Test load_art_trainer_settings with DEBUG log level."""
    env = make_fake_env()
    env.set("LOGGING__LEVEL", "DEBUG")
    cfg = load_art_trainer_settings()
    assert cfg["logging"]["level"] == "DEBUG"


def test_load_art_trainer_settings_log_level_warning() -> None:
    """Test load_art_trainer_settings with WARNING log level."""
    env = make_fake_env()
    env.set("LOGGING__LEVEL", "WARNING")
    cfg = load_art_trainer_settings()
    assert cfg["logging"]["level"] == "WARNING"


def test_load_art_trainer_settings_log_level_error() -> None:
    """Test load_art_trainer_settings with ERROR log level."""
    env = make_fake_env()
    env.set("LOGGING__LEVEL", "ERROR")
    cfg = load_art_trainer_settings()
    assert cfg["logging"]["level"] == "ERROR"


def test_load_art_trainer_settings_log_level_critical() -> None:
    """Test load_art_trainer_settings with CRITICAL log level."""
    env = make_fake_env()
    env.set("LOGGING__LEVEL", "CRITICAL")
    cfg = load_art_trainer_settings()
    assert cfg["logging"]["level"] == "CRITICAL"


def test_load_art_trainer_settings_custom_values() -> None:
    """Test load_art_trainer_settings with custom environment values."""
    env = make_fake_env()
    env.set("REDIS__ENABLED", "false")
    env.set("REDIS__URL", "redis://custom:6379/1")
    env.set("RQ__QUEUE_NAME", "custom-queue")
    env.set("APP__DATA_ROOT", "/custom/data")
    env.set("APP__KOHYA_SS_PATH", "/custom/kohya")
    env.set("APP__COMFYUI_LORA_PATH", "/custom/comfyui/loras")
    env.set("APP__BLIP_MODEL_NAME", "custom/blip-model")
    env.set("APP__CAPTION_TRIGGER_WORD", "xyz person")
    env.set("SECURITY__API_KEY", "secret-key")
    cfg = load_art_trainer_settings()
    assert cfg["redis"]["enabled"] is False
    assert cfg["redis"]["url"] == "redis://custom:6379/1"
    assert cfg["rq"]["queue_name"] == "custom-queue"
    assert cfg["app"]["data_root"] == "/custom/data"
    assert cfg["app"]["kohya_ss_path"] == "/custom/kohya"
    assert cfg["app"]["comfyui_lora_path"] == "/custom/comfyui/loras"
    assert cfg["app"]["blip_model_name"] == "custom/blip-model"
    assert cfg["app"]["caption_trigger_word"] == "xyz person"
    assert cfg["security"]["api_key"] == "secret-key"


def test_load_art_trainer_settings_log_level_invalid_uses_info() -> None:
    """Test load_art_trainer_settings uses INFO for invalid log level."""
    env = make_fake_env()
    env.set("LOGGING__LEVEL", "INVALID")
    cfg = load_art_trainer_settings()
    assert cfg["logging"]["level"] == "INFO"
