# Sixty-day crypto quote panel

Production implementation: API revision 8e02b3379b3be8b180c0de0822603c59fffabe2b,
package libs/covenant_ml. The later pacing change affects tests only; public
acquisition still uses real request pacing. Install the locked dependencies
with the existing Poetry/make harness. No credentials or funds are needed.

This bundle contains event-cohort, interval-quotes and prior-eight-day evidence
directories. Reconstruct the cohort first to bind a relocated quote report to
the extracted input paths. Run from libs/covenant_ml with fresh output names:

```powershell
.venv/Scripts/python.exe -m scripts.event_cohort --plan <bundle>/event-cohort/plan.json --archive <bundle>/event-cohort/raw --out <fresh-cohort.json> --mode replay
.venv/Scripts/python.exe -m scripts.interval_quotes --cohort <fresh-cohort.json> --plan <bundle>/interval-quotes/plan.json --archive <bundle>/interval-quotes/raw --out <fresh-quotes.json> --mode replay
```

All native cohort records, quote rows, statuses, cutoff and the acquisition
plan must match their originals. Source paths, implementation fingerprints
and the resulting cohort report hash may differ after relocation. Exact
checkout bytes, including line endings and platform_core, affect implementation
hashes. Never erase those provenance differences to claim byte identity.

The original sixty-day results.json and replay.json are byte-identical:
de068968848b800a391d5e7670cd65c95c611511aab2751ceb4ba9273132d87f.
The report verifies 556 source paths and contains 11,390 contract rows,
5,695 per asset. Every quote is two-sided and ends 60 seconds before the
fixed open-plus-five-minute decision. Both assets lack 65 of 5,760 nominal
close slots; no missing contract is imputed. Intervals and dates may share
market conditions and are not automatically independent observations.

verification.json is a second datetime/Decimal calculation directly from all
482 native envelopes, including 171,664 candles. It matches every selected
identity, price, eligible count and age, without using the production selector.
It also checks all 1,520 overlapping quote rows against the separately captured
eight-day report. The prior-eight-day directory preserves that report and all
of its raw quotes. It can be replayed with its own plan and archive using the
same command and freshly reconstructed cohort.

This is retrospective quote availability. No fitted model, executable fills,
cost-adjusted profit, independent future evaluation or predictive edge has
been established by this collection.
