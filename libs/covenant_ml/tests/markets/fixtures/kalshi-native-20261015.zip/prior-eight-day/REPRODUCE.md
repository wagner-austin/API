# Crypto prior quotes: reproduction

Implementation: API revision 8e02b3379b3be8b180c0de0822603c59fffabe2b,
package libs/covenant_ml. Install its locked dependencies with the existing
Poetry/make harness. The package passed full local make check: 4,353 tests,
100% statement and branch coverage. No live credentials or funds are needed.

The bundle contains two evidence directories: event-cohort and interval-quotes.
The original reports retain their original source paths. Rebuild the cohort
first so that a relocated quote run verifies paths in the extracted bundle.
From libs/covenant_ml, replacing the angle-bracket paths:

```powershell
.venv/Scripts/python.exe -m scripts.event_cohort --plan <bundle>/event-cohort/plan.json --archive <bundle>/event-cohort/raw --out <fresh-cohort.json> --mode replay
.venv/Scripts/python.exe -m scripts.interval_quotes --cohort <fresh-cohort.json> --plan <bundle>/interval-quotes/plan.json --archive <bundle>/interval-quotes/raw --out <fresh-quotes.json> --mode replay
```

Both operations are offline. The commands fail on missing or changed native
response bodies; they do not acquire substitute evidence. Output report and
RunRecord names must be new. Full cohort identities and native records must
match the original event-cohort/results.json. All quote contract rows, statuses,
cutoff and plan must match interval-quotes/results.json exactly.

Relocated reports have different source paths and therefore different hashes.
The quotes' cohort_sha256 consequently changes too. Implementation digests
include exact checkout bytes and installed platform_core bytes; line endings
or environment changes can change the digest. Arithmetic fingerprints may
also differ between machines. Preserve and explain those provenance changes;
do not erase them to manufacture byte identity.

The original quote results.json and replay.json match byte for byte with
SHA-256 200044456a7b9b8b4a1ce52e8af4eeeb83657eed04dafc24d8dcb7b60a5eb358.
verification.json records an independent datetime/Decimal reconciliation of
every selected identity, quote, eligible count and age against raw responses.
No production quote-selection function was used in that second calculation.

The measured panel has 1,520 contracts across 760 shared intervals and eight
UTC close dates. Both assets lack the same eight nominal slots on October 8.
Every observed contract has a two-sided candle ending 60 seconds before the
fixed open-plus-five-minute decision. Candles establish neither historical
receipt latency nor available execution size. This is exploratory data
availability, not a fitted forecasting result or evidence of profit.
