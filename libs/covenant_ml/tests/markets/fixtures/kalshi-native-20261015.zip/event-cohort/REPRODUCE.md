# Complete Kalshi event inventory, October 15, 2026

Implementation: API commit 1a898682522cceabfa881eec1d0ccbdb2088d32a,
package libs/covenant_ml. The acquisition changes are the four commits ending
at that revision. `make check` passed 4,318 tests with 100% statement and branch
coverage locally after rebasing onto the published main branch.

The fixed plan enumerates KXBTC15M, KXETH15M, KXNCAAFGAME and KXNFLGAME,
using capture-time close timestamps in [2026-07-01, 2026-10-15) UTC. This is
exploratory inventory, not a held-out predictive-performance result.

The archive includes every one of the 68 request envelopes consumed by the
completed run, original plan, report and sidecar, exact original replay and
sidecar, and independent native recount. Initial probe records and the
separate current exchange-schedule probe are not inputs to this report.

## Offline replay

Extract this bundle, install the package's locked dependencies using its
existing make/Poetry harness, and run from `libs/covenant_ml`:

```powershell
.venv/Scripts/python.exe -m scripts.event_cohort --plan <extracted>/plan.json --archive <extracted>/raw --out <new-report.json> --mode replay
```

Replay reads only archived requests. A missing envelope or changed response
body fails. It never substitutes a new network response. Choose an output
that does not exist; the report and sidecar use exclusive writes.

The original results.json and replay.json are byte-identical, SHA-256
b1d92dbebaef11f2ab95dc3ba75281eab1c7ab5f36aff2de2c4638e83b6c7cd8.
Their source paths name the original Windows evidence directory. A relocated
replay writes new source paths and fingerprints rather than pretending to
have run at the old location. Implementation digests also include exact file
bytes, including checkout line endings, and installed platform_core bytes;
semantic equivalence does not imply an identical implementation digest.
Compare the full native family inventories and counts, then explain any
provenance-only differences rather than deleting the provenance fields.

## Recorded verification

verification.json records matching report digests and 71 verified source paths
per report (68 envelopes, plan, report and sidecar). Its independent recount
uses datetime.fromisoformat() for local half-open filtering of every native
market page and Decimal for zero-volume classification. The selected ticker
sets, event counts and zero-volume counts agree with the production report.
The nominal crypto schedule is range(start_ts, end_ts, 900), compared against
the returned close timestamps. Each asset lacks the same 128 nominal slots;
all lie on Thursdays, but this alone does not prove their historical cause.

The first acquisition stopped because current and historical records differed
in open interest. Explicit reconciliation now preserves both nonnegative
observations; all other overlapping native fields must agree. The final run
deliberately resumed immutable saved requests and acquired missing requests.
The capture interval is 2026-10-15 20:38:13.926724 through 20:40:45.095367 UTC.

No model, prediction, execution price, fee assumption or profit estimate is
created by this command. Quotes and external predictors need their own
point-in-time availability evidence before a forecasting comparison.
